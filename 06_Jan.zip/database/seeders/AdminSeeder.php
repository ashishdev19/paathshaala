<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // ============================================
        // ADMIN DASHBOARD CREDENTIALS
        // ============================================
        // Email: admin@paathshaala.com
        // Password: admin123
        // ============================================
        
        $admin = User::updateOrCreate(
            ['email' => 'admin@paathshaala.com'],
            [
                'name' => 'Admin User',
                'password' => Hash::make('admin123'),
                'phone' => '+91 9999999999',
                'address' => 'Paathshaala Headquarters, New Delhi',
                'email_verified_at' => now(),
            ]
        );
        $admin->assignRole('admin');

        // ============================================
        // PROFESSOR/TEACHER DASHBOARD CREDENTIALS
        // ============================================
        // Email: professor@paathshaala.com
        // Password: professor123
        // ============================================
        
        $teacher = User::updateOrCreate(
            ['email' => 'professor@paathshaala.com'],
            [
                'name' => 'Dr. Rajesh Kumar',
                'password' => Hash::make('professor123'),
                'phone' => '+91 8888888888',
                'address' => 'Department of Computer Science, Mumbai',
                'email_verified_at' => now(),
            ]
        );
        $teacher->assignRole('instructor');

        // Alternative teacher account
        $teacher2 = User::updateOrCreate(
            ['email' => 'teacher@paathshaala.com'],
            [
                'name' => 'Prof. Priya Sharma',
                'password' => Hash::make('teacher123'),
                'phone' => '+91 8877665544',
                'address' => 'Department of Mathematics, Bangalore',
                'email_verified_at' => now(),
            ]
        );
        $teacher2->assignRole('instructor');

        // ============================================
        // STUDENT DASHBOARD CREDENTIALS
        // ============================================
        // Email: student@paathshaala.com
        // Password: student123
        // ============================================
        
        $student = User::updateOrCreate(
            ['email' => 'student@paathshaala.com'],
            [
                'name' => 'Amit Singh',
                'password' => Hash::make('student123'),
                'phone' => '+91 7777777777',
                'address' => 'Student Hostel, Pune',
                'email_verified_at' => now(),
            ]
        );
        $student->assignRole('student');

        // Additional student account
        $student2 = User::updateOrCreate(
            ['email' => 'student2@paathshaala.com'],
            [
                'name' => 'Sneha Patel',
                'password' => Hash::make('student123'),
                'phone' => '+91 7766554433',
                'address' => 'Student Residence, Delhi',
                'email_verified_at' => now(),
            ]
        );
        $student2->assignRole('student');

        echo "\n✅ Test users created successfully!\n";
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        echo "📧 ADMIN LOGIN\n";
        echo "   Email: admin@paathshaala.com\n";
        echo "   Password: admin123\n";
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        echo "📧 PROFESSOR LOGIN\n";
        echo "   Email: professor@paathshaala.com\n";
        echo "   Password: professor123\n";
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        echo "📧 STUDENT LOGIN\n";
        echo "   Email: student@paathshaala.com\n";
        echo "   Password: student123\n";
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
    }
}
