﻿{{-- Placeholder: shared\emails\welcome.blade.php --}}
