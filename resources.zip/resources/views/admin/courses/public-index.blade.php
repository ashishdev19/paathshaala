<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Courses - {{ config('app.name', 'Medniks') }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-lg shadow-sm border-b border-gray-100 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <!-- Logo -->
                <a href="{{ url('/') }}" class="flex items-center space-x-3 group">
                    <div class="relative">
                        <div class="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300">
                            <i class="fas fa-graduation-cap text-white text-sm"></i>
                        </div>
                        <div class="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    </div>
                    <div>
                        <h1 class="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Medniks</h1>
                        <p class="text-xs text-gray-500 font-medium">Medical Excellence</p>
                    </div>
                </a>
                
                <!-- Navigation Links -->
                <nav class="hidden md:flex items-center space-x-1">
                    <a href="{{ url('/') }}" class="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all font-medium">Home</a>
                    <a href="{{ route('courses.index') }}" class="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all font-medium">Courses</a>
                    <a href="{{ route('about') }}" class="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all font-medium">About</a>
                    <a href="{{ route('contact') }}" class="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all font-medium">Contact</a>
                </nav>
                
                <!-- Auth Links - Always visible -->
                <div class="flex items-center space-x-2">
                    @auth
                        <!-- User Dropdown -->
                        <div class="relative">
                            <button onclick="toggleUserDropdown()" class="flex items-center space-x-2 px-4 py-2 md:px-6 md:py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-sm md:text-base rounded-full hover:from-purple-700 hover:to-indigo-700 transition-all font-semibold shadow-md hover:shadow-lg transform hover:scale-[1.02]">
                                <span>{{ Auth::user()->name }}</span>
                                <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                </svg>
                            </button>
                            
                            <!-- Dropdown Menu -->
                            <div id="userDropdown" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-gray-100 py-2 z-50">
                                <a href="{{ url('/dashboard') }}" class="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-50 transition-colors">
                                    <svg class="w-4 h-4 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                    </svg>
                                    Profile Settings
                                </a>
                                <a href="#" class="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-50 transition-colors">
                                    <svg class="w-4 h-4 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"></path>
                                    </svg>
                                    My Certificates
                                </a>
                                <hr class="my-2">
                                <form action="{{ route('logout') }}" method="POST" class="inline w-full">
                                    @csrf
                                    <button type="submit" class="flex items-center w-full px-4 py-2 text-gray-700 hover:bg-gray-50 transition-colors text-left">
                                        <svg class="w-4 h-4 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                                        </svg>
                                        Logout
                                    </button>
                                </form>
                            </div>
                        </div>
                    @else
                        <a href="{{ route('login') }}" class="px-4 py-2 md:px-6 md:py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-sm md:text-base rounded-full hover:from-purple-700 hover:to-indigo-700 transition-all font-semibold shadow-md hover:shadow-lg transform hover:scale-[1.02] whitespace-nowrap">Login/Register</a>
                    @endauth
                    
                    <!-- Mobile Menu Button -->
                    <button class="md:hidden p-2 text-gray-600 hover:text-gray-900 focus:outline-none" onclick="toggleMobileMenu()">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div id="mobileMenu" class="hidden md:hidden bg-white border-t border-gray-100 shadow-lg">
            <div class="px-4 py-3 space-y-2">
                <a href="{{ url('/') }}" class="block px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all font-medium">Home</a>
                <a href="{{ route('courses.index') }}" class="block px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all font-medium">Courses</a>
                <a href="{{ route('about') }}" class="block px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all font-medium">About</a>
                <a href="{{ route('contact') }}" class="block px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all font-medium">Contact</a>
            </div>
        </div>
    </header>
<div class="min-h-screen bg-gray-50 pt-24 pb-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-4xl font-bold text-gray-900 mb-2">Browse Courses</h1>
            <p class="text-lg text-gray-600">Explore our comprehensive collection of courses and start learning today</p>
        </div>

        <!-- Filters -->
        <div class="bg-white rounded-lg shadow p-6 mb-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <input type="text" placeholder="Search courses..." class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                <div>
                    <select class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">All Categories</option>
                        <option value="medical">Medical</option>
                        <option value="nursing">Nursing</option>
                        <option value="pharmacy">Pharmacy</option>
                        <option value="engineering">Engineering</option>
                    </select>
                </div>
                <div>
                    <select class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">All Levels</option>
                        <option value="beginner">Beginner</option>
                        <option value="intermediate">Intermediate</option>
                        <option value="advanced">Advanced</option>
                    </select>
                </div>
                <div>
                    <select class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Sort by</option>
                        <option value="newest">Newest</option>
                        <option value="popular">Most Popular</option>
                        <option value="rating">Highest Rated</option>
                        <option value="price_low">Price: Low to High</option>
                        <option value="price_high">Price: High to Low</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Courses Grid -->
        @if($courses->count() > 0)
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                @foreach($courses as $course)
                    <div class="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden">
                        <!-- Course Image -->
                        <div class="relative bg-gray-200 h-48">
                            @if($course->thumbnail)
                                <img src="{{ asset($course->thumbnail) }}" alt="{{ $course->title }}" class="w-full h-full object-cover">
                            @else
                                <div class="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-400 to-blue-600">
                                    <i class="fas fa-book text-white text-6xl opacity-50"></i>
                                </div>
                            @endif
                            <div class="absolute top-3 right-3">
                                <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                                    {{ $course->level ?? 'Beginner' }}
                                </span>
                            </div>
                        </div>

                        <!-- Course Info -->
                        <div class="p-4">
                            <!-- Teacher -->
                            <div class="flex items-center mb-2">
                                <img src="{{ $course->teacher->profile_photo_url ?? asset('img/default-avatar.png') }}" alt="{{ $course->teacher->name }}" class="w-8 h-8 rounded-full mr-2">
                                <span class="text-sm text-gray-600">{{ $course->teacher->name }}</span>
                            </div>

                            <!-- Title -->
                            <h3 class="text-lg font-bold text-gray-900 mb-2 line-clamp-2">{{ $course->title }}</h3>

                            <!-- Description -->
                            <p class="text-sm text-gray-600 mb-3 line-clamp-2">{{ $course->description }}</p>

                            <!-- Rating -->
                            <div class="flex items-center mb-3">
                                @if($course->reviews_count > 0)
                                    @php
                                        $avgRating = $course->reviews->avg('rating');
                                    @endphp
                                    <div class="flex text-yellow-400">
                                        @for($i = 0; $i < 5; $i++)
                                            @if($i < round($avgRating))
                                                <i class="fas fa-star"></i>
                                            @else
                                                <i class="far fa-star"></i>
                                            @endif
                                        @endfor
                                    </div>
                                    <span class="text-sm text-gray-600 ml-2">({{ $course->reviews_count }})</span>
                                @else
                                    <span class="text-sm text-gray-500">No ratings yet</span>
                                @endif
                            </div>

                            <!-- Stats -->
                            <div class="flex items-center justify-between text-sm text-gray-600 mb-4 py-2 border-y">
                                <span><i class="fas fa-users mr-1"></i>{{ $course->enrollments_count ?? 0 }} students</span>
                                <span><i class="fas fa-clock mr-1"></i>{{ $course->duration ?? 0 }} hours</span>
                            </div>

                            <!-- Price and Button -->
                            <div class="flex items-center justify-between">
                                <div>
                                    <span class="text-2xl font-bold text-gray-900">₹{{ number_format($course->price ?? 0, 0) }}</span>
                                    @if($course->original_price && $course->original_price > $course->price)
                                        <span class="text-sm text-gray-500 line-through ml-2">₹{{ number_format($course->original_price, 0) }}</span>
                                    @endif
                                </div>
                            </div>

                            <!-- Button -->
                            <a href="{{ route('courses.show', $course->id) }}" class="block w-full mt-4 bg-blue-600 text-white py-2 rounded-lg text-center hover:bg-blue-700 transition font-semibold">
                                View Course
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>

            <!-- Pagination -->
            <div class="flex justify-center">
                {{ $courses->links() }}
            </div>
        @else
            <div class="bg-white rounded-lg shadow p-12 text-center">
                <i class="fas fa-book fa-4x text-gray-400 mb-4"></i>
                <h3 class="text-2xl font-bold text-gray-900 mb-2">No Courses Found</h3>
                <p class="text-gray-600 mb-6">We couldn't find any courses matching your criteria. Try adjusting your filters.</p>
                <a href="{{ route('courses') }}" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                    Browse All Courses
                </a>
            </div>
        @endif
    </div>
</div>

<footer class="bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 text-white">
    <!-- Newsletter Section -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-700 py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h3 class="text-4xl font-bold mb-4">Stay Updated with Medical Insights</h3>
            <p class="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">Get the latest medical research updates, course announcements, and exclusive healthcare content delivered to your inbox.</p>
            <div class="max-w-md mx-auto flex gap-4">
                <input type="email" placeholder="Enter your email address" class="flex-1 px-6 py-4 rounded-2xl text-gray-900 focus:outline-none focus:ring-4 focus:ring-blue-300">
                <button class="px-8 py-4 bg-white text-blue-600 rounded-2xl font-semibold hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg">Subscribe</button>
            </div>
        </div>
    </div>
    
    <!-- Main Footer Content -->
    <div class="py-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
                <!-- Company Info -->
                <div class="lg:col-span-2">
                    <div class="flex items-center gap-4 mb-6">
                        <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl">
                            <i class="fas fa-graduation-cap text-white text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-3xl font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">Medniks</h3>
                            <p class="text-blue-300 text-sm">Medical Education Excellence</p>
                        </div>
                    </div>
                    <p class="text-gray-300 mb-8 text-lg leading-relaxed max-w-lg">Transforming medical education in India through innovative online learning experiences. Join 50,000+ healthcare professionals advancing their careers with us.</p>
                    
                    <!-- Social Links -->
                    <div class="flex gap-4 mb-8">
                        <a href="#" class="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center hover:from-blue-500 hover:to-blue-600 transition-all transform hover:scale-110 shadow-lg" aria-label="Facebook">
                            <i class="fab fa-facebook-f text-white"></i>
                        </a>
                        <a href="#" class="w-12 h-12 bg-gradient-to-br from-sky-600 to-sky-700 rounded-2xl flex items-center justify-center hover:from-sky-500 hover:to-sky-600 transition-all transform hover:scale-110 shadow-lg" aria-label="Twitter">
                            <i class="fab fa-twitter text-white"></i>
                        </a>
                        <a href="#" class="w-12 h-12 bg-gradient-to-br from-pink-600 to-pink-700 rounded-2xl flex items-center justify-center hover:from-pink-500 hover:to-pink-600 transition-all transform hover:scale-110 shadow-lg" aria-label="Instagram">
                            <i class="fab fa-instagram text-white"></i>
                        </a>
                        <a href="#" class="w-12 h-12 bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-2xl flex items-center justify-center hover:from-indigo-500 hover:to-indigo-600 transition-all transform hover:scale-110 shadow-lg" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in text-white"></i>
                        </a>
                    </div>
                    
                    <!-- Trust Badges -->
                    <div class="flex gap-4 text-sm text-gray-400">
                        <div class="flex items-center gap-2">
                            <i class="fas fa-shield-alt text-green-500"></i>
                            <span>SSL Secured</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <i class="fas fa-award text-yellow-500"></i>
                            <span>ISO Certified</span>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div>
                    <h4 class="text-xl font-bold mb-6 text-white">Platform</h4>
                    <ul class="space-y-4">
                        <li><a href="{{ route('courses.index') }}" class="text-gray-300 hover:text-blue-400 transition-colors flex items-center gap-2 group"><i class="fas fa-arrow-right text-xs opacity-0 group-hover:opacity-100 transition-opacity"></i>Browse Courses</a></li>
                        <li><a href="{{ route('about') }}" class="text-gray-300 hover:text-blue-400 transition-colors flex items-center gap-2 group"><i class="fas fa-arrow-right text-xs opacity-0 group-hover:opacity-100 transition-opacity"></i>About Us</a></li>
                        <li><a href="#instructors" class="text-gray-300 hover:text-blue-400 transition-colors flex items-center gap-2 group"><i class="fas fa-arrow-right text-xs opacity-0 group-hover:opacity-100 transition-opacity"></i>Expert Faculty</a></li>
                        <li><a href="{{ route('contact') }}" class="text-gray-300 hover:text-blue-400 transition-colors flex items-center gap-2 group"><i class="fas fa-arrow-right text-xs opacity-0 group-hover:opacity-100 transition-opacity"></i>Contact Support</a></li>
                        <li><a href="#certifications" class="text-gray-300 hover:text-blue-400 transition-colors flex items-center gap-2 group"><i class="fas fa-arrow-right text-xs opacity-0 group-hover:opacity-100 transition-opacity"></i>Certifications</a></li>
                        <li><a href="#careers" class="text-gray-300 hover:text-blue-400 transition-colors flex items-center gap-2 group"><i class="fas fa-arrow-right text-xs opacity-0 group-hover:opacity-100 transition-opacity"></i>Careers</a></li>
                    </ul>
                </div>
                
                <!-- Medical Specializations -->
                <div>
                    <h4 class="text-xl font-bold mb-6 text-white">Specializations</h4>
                    <ul class="space-y-4">
                        <li><a href="#cardiology" class="text-gray-300 hover:text-red-400 transition-colors flex items-center gap-2 group"><i class="fas fa-heartbeat text-red-500 text-xs"></i>Cardiology</a></li>
                        <li><a href="#neurology" class="text-gray-300 hover:text-blue-400 transition-colors flex items-center gap-2 group"><i class="fas fa-brain text-blue-500 text-xs"></i>Neurology</a></li>
                        <li><a href="#surgery" class="text-gray-300 hover:text-orange-400 transition-colors flex items-center gap-2 group"><i class="fas fa-user-md text-orange-500 text-xs"></i>Surgery</a></li>
                        <li><a href="#pediatrics" class="text-gray-300 hover:text-green-400 transition-colors flex items-center gap-2 group"><i class="fas fa-child text-green-500 text-xs"></i>Pediatrics</a></li>
                        <li><a href="#radiology" class="text-gray-300 hover:text-indigo-400 transition-colors flex items-center gap-2 group"><i class="fas fa-x-ray text-indigo-500 text-xs"></i>Radiology</a></li>
                        <li><a href="#general-medicine" class="text-gray-300 hover:text-gray-400 transition-colors flex items-center gap-2 group"><i class="fas fa-stethoscope text-gray-500 text-xs"></i>General Medicine</a></li>
                    </ul>
                    
                    <!-- Contact Info -->
                    <div class="mt-12">
                        <h4 class="text-xl font-bold mb-6 text-white">Contact</h4>
                        <ul class="space-y-4">
                            <li class="flex items-start gap-3 text-gray-300">
                                <div class="w-8 h-8 bg-blue-600/20 rounded-lg flex items-center justify-center mt-0.5">
                                    <i class="fas fa-envelope text-blue-400 text-sm"></i>
                                </div>
                                <div>
                                    <div class="font-semibold text-white">Email Support</div>
                                    <div class="text-sm">support@medniks.com</div>
                                </div>
                            </li>
                            <li class="flex items-start gap-3 text-gray-300">
                                <div class="w-8 h-8 bg-green-600/20 rounded-lg flex items-center justify-center mt-0.5">
                                    <i class="fas fa-phone text-green-400 text-sm"></i>
                                </div>
                                <div>
                                    <div class="font-semibold text-white">24/7 Helpline</div>
                                    <div class="text-sm">+91-800-MEDICAL</div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Bottom Section -->
            <div class="pt-8 border-t border-gray-700">
                <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                    <div class="text-gray-400 text-center md:text-left">
                        <p>&copy; {{ date('Y') }} Medniks Medical Education Platform. All rights reserved.</p>
                    </div>
                    <div class="flex gap-6 text-sm">
                        <a href="#cookies" class="text-gray-400 hover:text-blue-400 transition-colors">Cookie Policy</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<script>
    // Mobile menu toggle
    function toggleMobileMenu() {
        const mobileMenu = document.getElementById('mobileMenu');
        mobileMenu.classList.toggle('hidden');
    }

    // User dropdown toggle
    function toggleUserDropdown() {
        const dropdown = document.getElementById('userDropdown');
        dropdown.classList.toggle('hidden');
    }

    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
        const dropdown = document.getElementById('userDropdown');
        const button = event.target.closest('button[onclick="toggleUserDropdown()"]');
        
        if (!button && dropdown && !dropdown.contains(event.target)) {
            dropdown.classList.add('hidden');
        }
    });

    // Header scroll effect
    window.addEventListener('scroll', function() {
        const header = document.querySelector('header');
        if (window.scrollY > 100) {
            header.classList.add('shadow-lg');
        } else {
            header.classList.remove('shadow-lg');
        }
    });
</script>
</body>
</html>
